class PortInUseError(Exception):
    
    def __init__(self, message ='Port already in use') -> None:
        super().__init__(message =message)