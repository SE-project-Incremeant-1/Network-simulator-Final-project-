class IP:
    def __init__(self, address:str, gateway:str, *, subnet ='255.255.255.0'): 
        self.address =address
        self.gateway =gateway
        self.subnet =subnet 