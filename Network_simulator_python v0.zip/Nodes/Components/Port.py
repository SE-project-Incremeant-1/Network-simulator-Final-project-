from .Interface import Interface 

class Port: 
    
    def __init__(self, number: int, interface:Interface):
        self.number =number
        self.interface =interface
        self._in_use =False

    @property
    def in_use(self): return self._in_use 

    @in_use.setter
    def in_use(self, is_it_in_use:bool): self._in_use =is_it_in_use