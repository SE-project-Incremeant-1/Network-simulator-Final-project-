from .Port import Port
from Nodes import Node
from Nodes.Exceptions import PortInUseError 

class Edge:
    
    src_node:Node =None
    dst_node:Node =None
    def __init__(self, label:str) -> None:
        self.label =label 
    
    def connect(self, src_node:Node, dst_node:Node, src_port:Port =None, dst_port:Port =None):

        # check if the porta are open
        # if not src.in_use or dst.in_use: raise PortInUseError()
        self.src_node =src_node
        self.dst_node =dst_node
        # self.src.in_use =True
        # self.dst.in_use =True