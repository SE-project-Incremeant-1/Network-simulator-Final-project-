from Network.Network import Network

def main(): 
    network =Network()

if __name__ =='__main__': main()