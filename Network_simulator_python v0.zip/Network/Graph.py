from Nodes.Components import Edge
from Nodes.Node import Node
import networkx as nx
import matplotlib.pyplot as plt 
from Nodes.EndDeviceNode import EndDeviceNode
from Nodes.SwitchNode import SwitchNode
from Nodes.RouterNode import RouterNode
 
class Graph(nx.Graph):

    node_list:'list[Node]' =[] 
    edge_list:'list[Edge]' =[]

    def __init__(self):
        super(Graph, self).__init__()
    
    def add_edges(self, edge_list:'list[Edge]'): 
        self.edge_list =[edge for edge in edge_list]
        self.add_edges_from([(edge.src_node.label, edge.dst_node.label) for edge in edge_list])
    
    def add_nodes(self, node_list: 'list[Node]'): 
        self.node_list =[node for node in node_list] 
        self.add_nodes_from([node.label for node in node_list]) 

    def create_graph(self, nodes:'list[Node]', edges:'list[Node]', *, display_graph =False): 
        self.add_nodes(nodes)
        self.add_edges(edges)
        if display_graph: self.draw_graph()

    def draw_graph(self):  
        plt.title("Network Archtecture")
        nx.draw(self, pos =nx.spring_layout(self, scale =3), with_labels =True, node_color ='purple', node_size =3000, font_color ='white', font_size =12, font_weight ='bold', font_family ='Times New Roman', width =1)
        plt.margins(.2)
        plt.show()