from .Graph import Graph
from Nodes.Components import Edge 
from Nodes import Node, SwitchNode, RouterNode, EndDeviceNode 

class Network:
 
    def __init__(self):
        self.graph =Graph()
        self._node_list:'list[Node]'  =[]
        self._edge_list:'list[Edge]' =[]
        self.create_network()
        self.connect_devices()
        self.graph.create_graph(self._node_list, self._edge_list, display_graph=True)

    @property
    def nodes(self): return self._node_list

    @property
    def edges(self): return self._edge_list

    def create_network(self): 
        device_count =int(input("[+] Number of PC's: "))
        switch_count =int(input("[+] Number of Switches: "))
        router_count =int(input("[+] Number of Routers: "))
        if device_count >0: self._node_list.extend([EndDeviceNode( {"FA": 1},  f'PC-{i +1}') for i in range(device_count)])
        if switch_count >0: self._node_list.extend([SwitchNode( {"GA": 2, "FA": 24},  f'S-{i +1}') for i in range(switch_count)])
        if router_count >0: self._node_list.extend([RouterNode( {"GA": 1, "FA": 4},  f'R-{i +1}') for i in range(router_count)])
    
    def connect_devices(self):   
        for i, node in enumerate(self._node_list): print(f'{i +1}: {node.label}') 
        for i, connection in enumerate(input("Pair devices: ").split(',')):
            src_id, dst_id =connection.strip().split(' ')
            src_node:Node =self._node_list[int(src_id) -1]
            dst_node:Node =self._node_list[int(dst_id) -1]
            edge =Edge('Ethernet')
            edge.connect(src_node, dst_node)
            self._edge_list.append(edge)

 