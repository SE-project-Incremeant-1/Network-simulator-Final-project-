from .Node import Node

class RouterNode(Node):
    """Router"""
    def __init__(self, ports: dict, label: str) -> None:
        super().__init__(ports, label)