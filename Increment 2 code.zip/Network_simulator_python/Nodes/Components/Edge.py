from .Port import Port
from Nodes import Node
from Nodes.Exceptions import PortInUseError 

class Edge:
    """
    Inter-device connections. Tracks devices linked
    """
    
    src_node:Node =None
    dst_node:Node =None
    def __init__(self, label:str) -> None:
        self.label =label 
    
    def connect(self, src_node:Node, dst_node:Node, src_port:Port =None, dst_port:Port =None)->Node:
        """
        Connects the devices on free ports

        :param src_node -{Node} source device
        :param dst_node -{Node} destination device
        :param src_port -{Port} source port
        :param dst_port -{Port} destination port
        :returns Node
        """
        # check if the porta are open before connecting
        if not src_port.in_use or dst_port.in_use: raise PortInUseError() 
        src_port.in_use =True
        dst_port.in_use =True