from Nodes.Components import IP, Port, Interface

class Node: 
    """
    Base device class
    """
    label: str =None 
    ports:'list[Port]' =[]
    
    def __init__(self, ports: dict, label:str) -> None:
        self._ip: IP =None
        self.label =label 
 
        self.ports =[Port(i, Interface(port)) for port,count in ports.items() for i in range(count)] 
    
    @property
    def ip(self): return self._ip

    @property
    def ip(self, ip:IP): self._ip =ip

    def __str__(self) -> str:
        return self.label
