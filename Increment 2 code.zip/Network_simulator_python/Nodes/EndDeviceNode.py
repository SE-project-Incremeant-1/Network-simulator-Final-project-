from .Node import Node

class EndDeviceNode(Node):
    """End device"""
    def __init__(self, ports: dict, label: str) -> None:
        super(EndDeviceNode, self).__init__(ports, label)
    
    def ping(self, dst_ip:str):
        pass