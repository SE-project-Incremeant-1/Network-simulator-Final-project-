from .Node import Node

class SwitchNode(Node):
    """Switch"""
    def __init__(self, ports: dict, label: str) -> None:
        super().__init__(ports, label)