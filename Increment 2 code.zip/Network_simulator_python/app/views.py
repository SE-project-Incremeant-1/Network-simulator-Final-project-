from flask import Blueprint, render_template, jsonify, url_for
from uuid import uuid4

views =Blueprint('views', __name__)

@views.route('/', methods =['GET']) 
def index():
    return render_template('index.html')

@views.route('/devices/<device>')
def get_devices(device:str):
    data  = {
        'end-device': {
            "icon": url_for('static', filename ='img/pc.png'),
            "devices":  [
                {"id": uuid4().hex, "label": 'HP-PC', "ports": [ {"pnumber": 0, "pinterface": 'FA'},] },
                {"id": uuid4().hex, "label": 'Dell',  "ports": [ {"pnumber": 0, "pinterface": 'GA'}, {"pnumber": 1, "pinterface": 'FA'}] }
            ]
        } ,
        "router": {
            "icon": url_for('static', filename ='img/router.png'),
            "devices": [
                {"id": uuid4().hex, "label": 'Router-A', "ports": [ {"pnumber": 0, "pinterface": 'GA'}, {"pnumber": 1, "pinterface": 'FA'}, {"pnumber": 2, "pinterface": 'FA'},]},
                {"id": uuid4().hex, "label": 'Router-B',  "ports": [ {"pnumber": 0, "pinterface": 'FA'}, {"pnumber": 1, "pinterface": 'FA'}]} 
            ]
        }
        , 
        'switch': {
            "icon": url_for('static', filename ='img/switch.png'),
            "devices": [
                {"id": uuid4().hex, "label": 'Switch-A',  "ports": [ {"pnumber": 0, "pinterface": 'GA'}, {"pnumber": 1, "pinterface": 'FA'}, {"pnumber": 2, "pinterface": 'FA'},]},
                {"id": uuid4().hex, "label": 'Switch-B', "ports": [ {"pnumber": 0, "pinterface": 'GA'}, {"pnumber": 1, "pinterface": 'GA'}, {"pnumber": 2, "pinterface": 'FA'}, {"pnumber": 3, "pinterface": 'FA'}]}
            ]
        },
        'connector': {
            "icon": url_for('static', filename ='img/usb.png'),
            "devices": [
                {"id": uuid4().hex, "name": 'Ethernet' }, 
            ]
        },
         
    }   
    response =data.get(device)  
    status_code =200 if response else 404 
    return jsonify(**response)  