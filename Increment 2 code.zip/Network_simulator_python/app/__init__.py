from flask import Flask
from .views import views
from pathlib import Path

def create_app():
    BASEDIR =Path(__file__).resolve().parent.parent 
    app =Flask(__name__, template_folder= BASEDIR /'templates', static_folder= BASEDIR /'static') 
    app.register_blueprint(views, url_prefix ='/')
    return app