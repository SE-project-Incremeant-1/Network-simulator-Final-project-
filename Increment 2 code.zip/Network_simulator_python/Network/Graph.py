from Nodes.Components import Edge
from Nodes.Node import Node
import networkx as nx
import matplotlib.pyplot as plt 
from Nodes.EndDeviceNode import EndDeviceNode
from Nodes.SwitchNode import SwitchNode
from Nodes.RouterNode import RouterNode
 
class Graph(nx.Graph):
    """
    Network Graph. Defines components of the network archtecture 
    """

    node_list:'list[Node]' =[] # list of devices making up the network
    edge_list:'list[Edge]' =[] # list of edges connecting the devices

    def __init__(self):
        super(Graph, self).__init__()
    
    def add_edges(self, edge_list:'list[Edge]')->None: 
        """
        Connects devices

        :param edge_list -{list[Node]} a list of Edge instances
        :returns None
        """
        self.edge_list =[edge for edge in edge_list]
        self.add_edges_from([(edge.src_node.label, edge.dst_node.label) for edge in edge_list])
    
    def add_nodes(self, node_list: 'list[Node]')->None: 
        """
        Add instances of device nodes to the network

        :param node_list -{list[Node]} a list of devices to make up the network
        :returns None
        """
        self.node_list =[node for node in node_list] 
        self.add_nodes_from([node.label for node in node_list]) 

    
    def create_graph(self, nodes:'list[Node]', edges:'list[Edge]', *, display_graph =False)->None: 
        """
        Initialize the graph. Set up devices and inter-connect them

        :param nodes -{list[Node]} a list of devices to make up the network
        :param edges -{list[Edge]} a list of connections defined between devices
        :param display_graph -{bool} specify whether or not to display the network archtecture
        :returns None
        """
        self.add_nodes(nodes)
        self.add_edges(edges)
        if display_graph: self.draw_graph()

     
    def draw_graph(self)->None:  
        """
        Visualize the network archtecture

        :returns None
        """
        plt.title("Network Archtecture")
        nx.draw(self, pos =nx.spring_layout(self, scale =3), with_labels =True, node_color ='purple', node_size =3000, font_color ='white', font_size =12, font_weight ='bold', font_family ='Times New Roman', width =1)
        plt.margins(.2)
        plt.show()