import {ConnectingDevice, EndDevice, RouterDevice, SwitchDevice} from './devices/index.js'; 

'use strict';
const latest_ids ={
    'end-device': 0,
    'connector': 0,
    'switch': 0,
    'router': 0
}
const cards =document.getElementById('cards');
const canvas_devices =[]; // devices dragged to the canvas
const pair =[]; // accepts 2 devices, src & dst 
const canvas =document.getElementById('canvas');
let selectedElement =null;
let draggableDevices =[]; // devices listed ready for dragging
const deviceList =document.getElementById('deviceList');  
const modifyDom =(parent, dataArray, draggable =false) =>{ 
    parent.innerHTML ='';
    dataArray.forEach(({id, icon, device_name, label}) =>{ 
        const child =device_name ==='connector'? `<div class ="rod" data-role ="connector"><button class ="hook" data-point ="top"></button><button class ="hook" data-point ="bottom"></button></div>`:`<img src="${icon}" alt="${device_name}" draggable="false"/><p id ="device-label">${label}</p>`
        parent.innerHTML =`
        ${parent.innerHTML} 
        <div class ="filled" draggable ="${draggable}" data-device-type ="${device_name}" data-device-id ="${id}">
        ${child}
        </div>
        `; 
    });
    
    return parent;
}
const initMotionOnCanvas =() =>{
    [...canvas.children].forEach(child =>{  
            child.addEventListener('mousedown',  ()=>{
                selectedElement =child;
                document.addEventListener('mousemove', e =>{ 
                    if(selectedElement){ 
                        selectedElement.style.setProperty('--left', `${e.pageX-175}px`);
                        selectedElement.style.setProperty('--top', `${e.pageY-100}px`);
                    }
                }); 
            }); 
            document.onmouseup =() => selectedElement =null; 
    }); 
}
const initDrag =() =>{ 
    [...deviceList.children].forEach(child =>{  
        child.addEventListener('dragstart', onDragStart, false);
        child.addEventListener('dragend', onDragEnd, false); 
    }); 
}
 

const onDragStart =evt =>{ 
    const target =evt.currentTarget;   
    evt.dataTransfer.setData('text', [...deviceList.children].indexOf(target)); 
}

const onDragEnd =(e) =>e.preventDefault();

const onDragEnter =e =>{
    e.preventDefault();
    e.target.classList.add('focused');
}

const onDragOver =e =>{
    e.preventDefault()
}

const onDrop =e =>{
    e.preventDefault();   
    const id =e.dataTransfer.getData('text'); 
    const contextMenu =document.getElementById('context-menu');
    try {
        let targetNode = [...deviceList.children][id]; 
        targetNode =targetNode.cloneNode(true);
        targetNode.classList.add('ps-absolute'); 
        targetNode.removeAttribute('draggable'); 
        canvas.append(targetNode);  
        targetNode.style.setProperty('--top', `${e.offsetY-30}px`);
        targetNode.style.setProperty('--left', `${e.offsetX-30}px`);
        targetNode.addEventListener('contextmenu', e=>{
            e.preventDefault(); 
            contextMenu.style.visibility ="visible"; 
            let x =e.pageX, y =e.pageY;  
            contextMenu.style.left =`${x}px`;
            contextMenu.style.top =`${y}px`;
        })
        document.onclick =e =>{ contextMenu.style.visibility ="hidden";  }
        const {ports, label, device_name} =draggableDevices.find(({id}) =>id ===targetNode.getAttribute('data-device-id'))
        const new_label =`${label}-${latest_ids[device_name]}`; 
        if(device_name !=='connector') targetNode.querySelector('#device-label').textContent =new_label;
        switch(targetNode.getAttribute('data-device-type').toLowerCase()){
            case 'end-device':  
                const end_device =new EndDevice(new_label, ports);
                end_device.id =Date.now();
                canvas_devices.push(end_device); 
                break;
            case 'connector': 
                const conn_device =new ConnectingDevice(new_label);
                conn_device.id =Date.now().toString(36);
                canvas_devices.push(conn_device);  
                break
            case 'switch': 
                const switch_device =new SwitchDevice(new_label, ports);
                switch_device.id =Date.now().toString(36);
                canvas_devices.push(switch_device); 
                break
            case 'router': 
                const router_device =new RouterDevice(new_label, ports);
                router_device.id =Date.now().toString(36);
                canvas_devices.push(router_device); 
                break
            default: break;
        } 
        latest_ids[device_name] +=1;
    }catch ({message}) { console.log(message);} 
    e.target.classList.remove('focused');
    initMotionOnCanvas();   
    
}

const onDragLeave =e =>{
    e.preventDefault();
    e.target.classList.remove('focused');
}
 
canvas.addEventListener('dragenter', onDragEnter);
canvas.addEventListener('dragover', onDragOver);
canvas.addEventListener('drop', onDrop);
canvas.addEventListener('dragleave', onDragLeave);

initDrag();

[...document.querySelectorAll('[data-device]')].forEach(device =>{
    device.addEventListener('click', async e=>{
        e.preventDefault(); 
        draggableDevices =[];
        const {target} =e;
        deviceList.innerHTML ='<p class="loader hidden">Fetching please wait...</p>';
        const device_name =target.getAttribute('data-device-type'); 
        const response =await fetch(`/devices/${device_name}`);
        const {icon, devices} =await response.json();  
        devices.forEach(({label, name, ports, id}) =>{  
            draggableDevices.push({
                id,
                icon,
                device_name,
                label: name? name: label,
                ports
            });
        });
        modifyDom(deviceList, draggableDevices, true); 
        initDrag();
    }) 
})  

document.getElementById('close').
addEventListener('click', () =>document.getElementById('modal').classList.add('hidden'));

document.getElementById('connection').addEventListener('click', () =>{
    cards.innerHTML ='';
    let card ='';
    if(canvas_devices.length >=2){
        canvas_devices.forEach(device =>{
            let open_port_ids =[]
            const open_ports =device.ports.filter(({pin_use}) =>!pin_use).
            map(port => {
                open_port_ids.push(`<div class="">${port.pinterface.name}/${port.pnumber}</div>`);
                return `<input type ='radio' value ='${device.id}-${port.pnumber}' name ='${device.label}'/>`;
            }).join(''); 
            if(open_ports.length >0){
                card =`${card}
                <div class="card">
                    <h3>${device.label}</h3> 
                    <div class="ports">${open_ports}</div>
                    <div class="port_names">${open_port_ids.join('')}</div>
                </div> 
                `; 
            }
            open_port_ids =[]; 
        });
        cards.innerHTML =card;
        document.getElementById('modal').classList.remove('hidden'); 
    }
});