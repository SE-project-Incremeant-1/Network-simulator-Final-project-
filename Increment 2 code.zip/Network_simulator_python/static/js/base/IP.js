'use strict';

class IP{
    address =null;
    gateway =null;
    subnet =null;
    constructor(address, gateway, subnet){
        this.address =this.#validate_entry(address);
        this.gateway =this.#validate_entry(gateway);
        this.subnet =this.#validate_entry(subnet);
    }

    #validate_entry(entry){ 
        const ip_tokens =entry.split('.');
        if(ip_tokens.length !==4)  return;
        ip_tokens.forEach(token =>{
            try{
                const int_token =parseInt(token);
                if(int_token <0 ||int_token >255) console.error('Invalid IP address')
            }catch({message}){console.error(message)}
        });
        return entry;
    }
}

export default IP;