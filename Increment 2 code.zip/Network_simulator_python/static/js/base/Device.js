import IP from './IP.js';
import Port from './Port.js';
import Interface from './Interface.js';

'use strict';

class Device {
    id =null;
    label =null; 
    ports =[];
    ip =null;
    icon =null;
    configured =false;

    constructor(label, ports) {
        this.label =label
        this.ports =ports.map(({pnumber, pinterface}) =>new Port(pnumber, new Interface(pinterface)));
    }

    setIp(address, gateway,  subnet='255.255.255.0'){
        this.ip =new IP(address, gateway, subnet);
    }

    configure(){
        this.configured =true;

        return this.configured;
    }
}

export default Device; 