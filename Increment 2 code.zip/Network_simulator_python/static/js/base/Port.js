'use strict';

class Port{
    pnumber =null;
    pinterface =null;
    pin_use =false;
    constructor(pnumber, pinterface) {
        this.pnumber =pnumber;  
        this.pinterface =pinterface;
    }

}

export default Port;