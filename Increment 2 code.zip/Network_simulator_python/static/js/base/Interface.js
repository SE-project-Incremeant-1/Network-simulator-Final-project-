'use strict';

class Interface{
    name =null;
    constructor(name){
        this.name =name;
    }
}

export default Interface;