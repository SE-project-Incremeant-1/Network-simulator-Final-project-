import Device from '../base/Device.js'; 
'use strict';

class EndDevice extends Device{
    constructor(label, ports){
        super(label, ports)
    } 
}

export default EndDevice;