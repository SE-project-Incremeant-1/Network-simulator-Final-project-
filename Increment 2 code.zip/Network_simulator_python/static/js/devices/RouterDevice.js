import Device from '../base/Device.js'; 
'use strict';

class RouterDevice extends Device{
    constructor(label, ports){
        super(label, ports)
    } 
}

export default RouterDevice;