
class ConnectingDevice{
    src_device =null;
    dst_device =null;
    src_port =null;
    dst_port =null;
    name =null;
    ends_connected =false; 

    constructor(name){
        this.name =name;
    }

    connect(src_d, src_pn, dst_d, dst_pn){ 
        if(this.ends_connected) this.disconnect();
        const src_p =src_d.ports.find(port =>port.pnumber =src_pn && !port.pin_use);
        const dst_p =dst_d.ports.find(port =>port.pnumber =dst_pn && !port.pin_use);
        if((src_p && dst_p) && src_p.pinterface.name ===dst_p.pinterface.name) { 
            src_p.pin_use =true;
            dst_p.pin_use =true;
            this.src_device =src_d;
            this.dst_device =dst_d;
            this.src_port =src_p;
            this.dst_port =dst_p;
            this.ends_connected =true
        }
        return this.ends_connected;
    }

    disconnect(){ 
        if(this.ends_connected){ 
            this.src_port.pin_use =false;
            this.dst_port.pin_use =false;
            this.src_port =null;
            this.dst_port =null;
            this.src_device =null;
            this.dst_device =null;
            this.ends_connected =false; 
        }
        return this.ends_connected;
    }
    
    ends_configured() {
        return this.src_device.configured && this.dst_device.configured;
    }
} 

export default ConnectingDevice;