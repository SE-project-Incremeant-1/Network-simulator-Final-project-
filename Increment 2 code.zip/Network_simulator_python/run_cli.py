from Network import Network

def main():
    # Initialize the Network
    network =Network()
if __name__ =='__main__': main()